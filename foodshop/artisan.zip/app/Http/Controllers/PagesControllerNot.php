<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



class PagesController extends Controller
{
    public function controller(){
//        return view('controllertest');
        return 'controllertest';
    }
}